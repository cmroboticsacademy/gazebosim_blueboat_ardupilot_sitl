from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        ExecuteProcess(
            cmd=[
                'env',
                'LIBGL_ALWAYS_SOFTWARE=1',
                'gz',
                'sim',
                '--force-version',
                '7',
                '-r',
                '-s',
                'level6.sdf',
            ],
            output='screen',
        ),

        Node(
            package='ros_ign_bridge',
            executable='parameter_bridge',
            arguments=[
                # Boat 1 / ArduPilot instance 0 / SYSID 1
                '/model/blueboat/joint/motor_port_joint/cmd_thrust@std_msgs/msg/Float64@ignition.msgs.Double',
                '/model/blueboat/joint/motor_stbd_joint/cmd_thrust@std_msgs/msg/Float64@ignition.msgs.Double',
                '/model/blueboat/odometry@nav_msgs/msg/Odometry@ignition.msgs.Odometry',
                '/navsat@sensor_msgs/msg/NavSatFix@ignition.msgs.NavSat',
                '/bathymetry/scan@sensor_msgs/msg/LaserScan@ignition.msgs.LaserScan',

                # Boat 2 / ArduPilot instance 1 / SYSID 2
                '/model/blueboat2/joint/motor_port_joint/cmd_thrust@std_msgs/msg/Float64@ignition.msgs.Double',
                '/model/blueboat2/joint/motor_stbd_joint/cmd_thrust@std_msgs/msg/Float64@ignition.msgs.Double',
                '/model/blueboat2/odometry@nav_msgs/msg/Odometry@ignition.msgs.Odometry',
                '/blueboat2/navsat@sensor_msgs/msg/NavSatFix@ignition.msgs.NavSat',
                '/blueboat2/bathymetry/scan@sensor_msgs/msg/LaserScan@ignition.msgs.LaserScan',
            ],
            output='screen',
        ),
    ])
