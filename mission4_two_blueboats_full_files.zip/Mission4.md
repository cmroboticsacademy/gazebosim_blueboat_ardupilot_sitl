# Mission 4: Two BlueBoats in one Gazebo scene

Mission 4 launches two physics-enabled BlueBoat vehicles in `level6.sdf`. Each boat runs its own ArduPilot SITL instance and uses a different MAVLink system ID so QGroundControl can show and control them as two separate vehicles.

## Terminal layout

Use four terminals:

- **T1:** Gazebo / ROS 2 launch
- **T2:** ArduPilot SITL for Boat 1
- **T3:** ArduPilot SITL for Boat 2
- **T4:** QGroundControl

Start the Docker container the same way as the earlier missions before running these commands.

## T1: Launch Gazebo Mission 4

Enter the container if needed, then go to the Gazebo workspace:

```bash
cd ../gz_ws/
```

Build and source the ROS 2 workspace after adding the Mission 4 files:

```bash
colcon build --packages-select move_blueboat
source install/setup.bash
source gazebo_exports.sh
```

Launch the two-boat world:

```bash
ros2 launch move_blueboat mission4_sim.launch.py
```

The world file is `level6.sdf`. It starts:

- `blueboat` at `0 -0.75 0 0 0 -1.5708`
- `blueboat2` at `0 0.75 0 0 0 -1.5708`

Both vehicles are dynamic models, so Gazebo physics, hydrodynamics, thrusters, IMU, NavSat, and odometry are active.

## T2: Launch ArduPilot for Boat 1

Enter the Docker container in a second terminal:

```bash
sudo docker exec -it blueboat_sitl /bin/bash
```

Go to the ArduPilot directory:

```bash
cd ../ardupilot
```

Start the first SITL instance. This instance talks to the original `blueboat` Gazebo model on FDM port `9002` and uses MAVLink system ID `1`.

```bash
sim_vehicle.py -v Rover -f gazebo-rover --model JSON \
  --add-param-file=../gz_ws/cmra_boat.params -w \
  -I0 --sysid 1 \
  -l 40.595009,-79.99974,0,0 \
  --out=udp:127.0.0.1:14550 \
  --out=udp:127.0.0.1:14551
```

## T3: Launch ArduPilot for Boat 2

Enter the Docker container in a third terminal:

```bash
sudo docker exec -it blueboat_sitl /bin/bash
```

Go to the ArduPilot directory:

```bash
cd ../ardupilot
```

Start the second SITL instance. This instance talks to the added `blueboat2` Gazebo model on FDM port `9012` and uses MAVLink system ID `2`.

```bash
sim_vehicle.py -v Rover -f gazebo-rover --model JSON \
  --add-param-file=../gz_ws/cmra_boat.params -w \
  -I1 --sysid 2 \
  -l 40.595009,-79.99974,0,0 \
  --out=udp:127.0.0.1:14550 \
  --out=udp:127.0.0.1:14561
```

Both ArduPilot instances send MAVLink telemetry to UDP port `14550`, so QGroundControl can discover both vehicles through its normal UDP link. The second vehicle also has a separate extra output on `14561` for debugging or MAVProxy connections.

## T4: Launch QGroundControl

Go to the QGroundControl folder:

```bash
cd QGroundControl/
```

Launch QGroundControl:

```bash
./QGroundControl-x86_64.AppImage
```

QGroundControl should show two vehicles:

- Vehicle / system ID `1`: `blueboat`
- Vehicle / system ID `2`: `blueboat2`

Use QGroundControl's vehicle selector to switch between them. Arm, disarm, change mode, and send commands to the selected vehicle only.

## Resetting Mission 4

Stop both ArduPilot terminals with `Ctrl+C`.

Stop Gazebo with `Ctrl+C` in T1.

Then relaunch in this order:

1. T1: `ros2 launch move_blueboat mission4_sim.launch.py`
2. T2: Boat 1 `sim_vehicle.py` command
3. T3: Boat 2 `sim_vehicle.py` command
4. T4: QGroundControl, if it is not already running

## Troubleshooting

If only one vehicle appears in QGroundControl, confirm that both ArduPilot commands include `--out=udp:127.0.0.1:14550` and that Boat 1 uses `--sysid 1` while Boat 2 uses `--sysid 2`.

If Boat 2 does not move, confirm that `SITL_Models/Gazebo/models/blueboat2/model.sdf` exists and contains `fdm_port_in` set to `9012`. Boat 2 must be launched with `sim_vehicle.py -I1` so the ArduPilot instance and Gazebo plugin use the same FDM port family.

If Gazebo cannot find `level6.sdf` or `blueboat2`, source the Gazebo exports again:

```bash
cd ../gz_ws/
source gazebo_exports.sh
```
